<?php include 'include/header.php'; ?>

<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel" data-interval="3000">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item position-relative active">
      <img src="images/sliders/slider-img1.jpg" class="d-block w-100 image-filter object-cover" alt="">

      <div class="carousel-caption">
        <div class="text-left">

          <p class="carousel-title mt-3">Excavating Excellence<br>Every Time</p>
          <p class="carousel-para">Your Trusted Partner for Precision Earthworks, Excavation, and Material Supply.</p>

        </div>
      </div>
    </div>
    <div class="carousel-item position-relative">
      <img src="images/sliders/slider-img2.jpg" class="d-block w-100 image-filter object-cover" alt="">

      <div class="carousel-caption">
        <div class="text-left">

          <p class="carousel-title mt-3">Shaping Landscapes<br>Building Dreams</p>
          <p class="carousel-para">Bringing Your Projects to Life, Safely and Sustainably. </p>

        </div>
      </div>
    </div>
  </div>
</div>


<div class="row my-5 align-items-end">
  <div class="col-lg-6 col-md-12 col-sm-12">
    <div class="px-4">
      <div class="border-left-thick pl-3">
        <p class="h5 mb-3" data-aos="fade-in" data-aos-duration="1000" data-aos-once="true">About us</p>
        <p class="h2" data-aos="fade-left" data-aos-duration="2000" data-aos-once="true">In the Beginning</p>
      </div>
      <div class="pl-3 mt-5">
        <p class="text-dark">In the late 1990s, the story of <span class="font-weight-bold">Mother Transport</span>
          began with a passionate and hardworking individual, Mr. R.
          KUPPUSAMY. From the humble role of a laborer, he quickly rose to become a labor contractor, and by 2001, he
          was handling the supply of bulk materials with just a single lorry. A visionary in the making, he expanded his
          endeavors, diving into both labor contracting and material supply, laying the foundation for Mother Transport.
        </p>
      </div>
      <button class="btn btn-primary ml-3 mt-4" data-aos="fade-up" data-aos-duration="2000" data-aos-once="true">Learn More</button>
    </div>
  </div>
  <div class="col-lg-6 col-md-12 col-sm-12">
    <div class="beginning-img" data-aos="fade-left" data-aos-duration="2000" data-aos-once="true">
      <img src="images/homepage/indian_lorry.jpg" class="object-cover">
    </div>
  </div>
</div>


<div class="row py-5">
  <div class="col-lg-6 col-md-6 col-sm-12">
    <div class="row mx-3 mx-md-0">

      <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="p-4 bg-light my-3 mt-md-0">
          <div class="services_img">
          <img src="images/homepage/excavator.png" alt="" class="object-cover">
          </div>
          <i class="thick-border-line"></i>
          <p class="h3 mt-3">Drilling and Blasting</p>
          <p class="h6">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum, impedit.</p>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="p-4 my-2 bg-light my-3 mt-md-0">
          <div class="services_img">
          <img src="images/homepage/excavator.png" alt="" class="object-cover">
          </div>
          <i class="thick-border-line"></i>
          <p class="h3 mt-3">Drilling and Blasting</p>
          <p class="h6">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum, impedit.</p>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="p-4 bg-light my-3 mt-md-0">
          <div class="services_img">
            <img src="images/homepage/excavator.png" alt="" class="object-cover">
          </div>
          <i class="thick-border-line"></i>
          <p class="h3 mt-3">Drilling and Blasting</p>
          <p class="h6">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum, impedit.</p>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="p-4 bg-light my-3 mt-md-0">
          <div class="services_img">
            <img src="images/homepage/excavator.png" alt="" class="object-cover">
          </div>
          <i class="thick-border-line"></i>
          <p class="h3 mt-3">Drilling and Blasting</p>
          <p class="h6">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum, impedit.</p>
        </div>
      </div>

    </div>
  </div>
  <div class="col-lg-6 col-md-6 col-sm-12">
    <div class="pl-4">
      <div class="mb-3 border-left pl-3">
        <p class="h5 mb-3">Our Services</p>
        <p class="h1">What we</p>
        <p class="h1">can Offer</p>
      </div>
      <div class="mt-lg-4 ml-lg-4">
        <p>We offer a diverse range of services to cater to your needs, including Foundation Works, Road Work, Material
          Supply, and Demolition Work. With our experienced team and top-notch equipment, your projects are in safe
          hands.</p>
      </div>
    </div>
  </div>

</div>

<div class="container my-3 py-3">
  <div class="d-flex align-items-center justify-content-between">
    <p class="py-5 h5 d-none d-md-block" data-aos="fade-right" data-aos-duration="2000" data-aos-once="true"> <span
        class="text-primary">Our</span> Projects <i class="border-primary heading-line"></i></p>
    <p class="h3" data-aos="fade-left" data-aos-duration="2000" data-aos-once="true"><span
        class="text-primary">Projects</span> We Done Before</p>
  </div>
  <div class="our-projects bg-light py-3" data-aos="fade-up" data-aos-duration="2000" data-aos-once="true">

    <div class="p-3">
      <div class="project-images">
        <img src="images/projects/project_1.webp" class="object-cover br-rounded" alt="">
        <div class="project-contents">
          <p><span class="font-weight-bold">Name:</span> Chandrakala Resort</p>
          <p><span class="font-weight-bold">Place:</span> ECR</p>
        </div>
      </div>
    </div>
    <div class="p-3">
      <div class="project-images">
        <img src="images/projects/project_2.webp" class="object-cover br-rounded" alt="">
        <div class="project-contents">
          <p><span class="font-weight-bold">Name:</span> SRINIVASAN ASSOCIATES</p>
          <p><span class="font-weight-bold">Place:</span> Pallavaram</p>
        </div>
      </div>
    </div>
    <div class="p-3">
      <div class="project-images">
        <img src="images/projects/project_3.webp" class="object-cover br-rounded" alt="">
        <div class="project-contents">
          <p><span class="font-weight-bold">Name:</span> Power Builders</p>
          <p><span class="font-weight-bold">Place:</span> ECR</p>
        </div>
      </div>
    </div>
    <div class="p-3">
      <div class="project-images">
        <img src="images/projects/project_4.webp" class="object-cover br-rounded" alt="">
        <div class="project-contents">
          <p><span class="font-weight-bold">Name:</span> GC Lifespace</p>
          <p><span class="font-weight-bold">Place:</span> DRA Kovilambakkam</p>
        </div>
      </div>
    </div>
    <div class="p-3">
      <div class="project-images">
        <img src="images/projects/project_5.webp" class="object-cover br-rounded" alt="">
        <div class="project-contents">
          <p><span class="font-weight-bold">Name:</span> KAVYA ENTERPRISES</p>
          <p><span class="font-weight-bold">Place:</span> Kotturpuram</p>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container my-3 py-3">
  <div class="d-flex align-items-center justify-content-between">
    <p class="h3" data-aos="fade-right" data-aos-duration="2000" data-aos-once="true"><span class="text-primary">What
        can</span> we offer</p>
    <p class="py-5 h5 d-none d-md-block" data-aos="fade-left" data-aos-duration="2000" data-aos-once="true"><i
        class="border-primary heading-line"></i> <span class="text-primary">Our</span> Services</p>
  </div>
  <div class="row">

    <div class="col-lg-8 col-md-6 col-sm-12 order-2 order-md-1">
      <p class="mt-3 mt-md-0 text-justify" data-aos="fade-up" data-aos-duration="2000" data-aos-once="true">At MTEM, we
        offer a comprehensive suite of construction services to bring your vision to life. From sturdy foundations to
        expert construction, reliable material supply, efficient demolitions, and road projects, we've got it all
        covered.</p>
      <div class="row mt-3">

        <a href="#" class="col-lg-6 col-md-6 col-sm-12 p-2 pt-5 " data-aos="fade-up" data-aos-duration="2000"
          data-aos-once="true">
          <div href="#" class="d-flex justify-content-between align-items-center hover-box-shadow services-box">
            <div>

              <div class="example-img mx-3">
                <img src="images/homepage/excavation.png" class="object-contain" alt="">
                <img src="images/homepage/excavation1.png" class="object-contain" alt="">
              </div>
            </div>
            <div>
              <p class="h5 text-primary">Excavation</p>
              <div class="">
                <p class="text-gray">Precise and efficient excavation services tailored to your project's requirements
                </p>
              </div>
            </div>
          </div>
        </a href="#">
        <a class="col-lg-6 col-md-6 col-sm-12 p-2 pt-5 " data-aos="fade-up" data-aos-duration="2000"
          data-aos-once="true">
          <div class="d-flex justify-content-between align-items-center hover-box-shadow services-box">
            <div>

              <div class="example-img mx-3">
                <img src="images/homepage/excavator.png" class="object-contain" alt="">
                <img src="images/homepage/excavator1.png" class="object-contain" alt="">
              </div>

            </div>
            <div>
              <p class="h5 text-primary">Earth-Moving Services</p>
              <div class="">
                <p class="text-gray">Skilled earth-moving operators and modern equipment for diverse projects.</p>
              </div>
            </div>
          </div>
        </a>
        <a href="#" class="col-lg-6 col-md-6 col-sm-12 p-2 pt-5" data-aos="fade-up" data-aos-duration="2500"
          data-aos-once="true">
          <div class="d-flex justify-content-between align-items-center hover-box-shadow services-box">
            <div>

              <div class="example-img mx-3">
                <img src="images/homepage/material.webp" class="object-contain" alt="">
                <img src="images/homepage/material.png" class="object-contain" alt="">
              </div>
            </div>
            <div>
              <p class="h5 text-primary">Material Supply</p>
              <div class="">
                <p class="text-gray">A diverse range of construction materials, including aggregates, sand, gravel, and
                  more.</p>
              </div>
            </div>
          </div>
        </a>


        <a href="#" class="col-lg-6 col-md-6 col-sm-12 p-2 pt-5 " data-aos="fade-up" data-aos-duration="3000"
          data-aos-once="true">
          <div class="d-flex justify-content-between align-items-center hover-box-shadow services-box">
            <div>

              <div class="example-img mx-3">
                <img src="images/homepage/manager.png" class="object-contain" alt="">
                <img src="images/homepage/manager1.png" class="object-contain" alt="">
              </div>
            </div>
            <div>
              <p class="h5 text-primary"> Project Management</p>
              <div class="">
                <p class="text-gray">Clear communication and collaboration to ensure your project's success</p>
              </div>
            </div>
          </div>
        </a>

      </div>
    </div>
    <div class="col-lg-4 col-md-6 col-sm-12 order-1 order-md-2 d-none d-md-block" data-aos="fade-up"
      data-aos-duration="2000" data-aos-once="true">
      <div class="services-img">
        <img src="images/homepage/services_img.jpg" class="object-cover br-rounded" alt="">
      </div>
    </div>
  </div>
</div>

<div class="container my-3 py-3">
  <div class="text-center my-3">
    <p class="h3" data-aos="fade-up" data-aos-duration="2000" data-aos-once="true"><span class="text-primary">WHAT
        OUR</span> CLIENT SAYS</p>
  </div>
  <div class="client-review bg-light" data-aos="fade-up" data-aos-duration="3000" data-aos-once="true">
    <div class="p-3">
      <div class="client-review-card">
        <i class="fa-solid fa-quote-left"></i>
        <p>MTEM Construction exceeded my expectations! Their attention to detail and commitment to quality are
          unmatched. I couldn't be happier with the results.</p>
        <p class="client-name">John D </p>
      </div>
    </div>
    <div class="p-3">
      <div class="client-review-card">
        <i class="fa-solid fa-quote-left"></i>
        <p>I had a tight deadline for my project, and MTEM delivered on time without compromising quality. Their
          professionalism and efficiency are truly commendable.</p>
        <p class="client-name">Gokul </p>
      </div>
    </div>
    <div class="p-3">
      <div class="client-review-card">
        <i class="fa-solid fa-quote-left"></i>
        <p>MTEM Construction is my go-to for all construction needs. They consistently provide top-notch service, and
          their team is a pleasure to work with."</p>
        <p class="client-name">David M</p>
      </div>
    </div>
    <div class="p-3">
      <div class="client-review-card">
        <i class="fa-solid fa-quote-left"></i>
        <p>The MTEM team transformed my property with their expertise. The finished project is not only structurally
          sound but also visually stunning.</p>
        <p class="client-name">Emily P</p>
      </div>
    </div>
    <div class="p-3">
      <div class="client-review-card">
        <i class="fa-solid fa-quote-left"></i>
        <p>I highly recommend MTEM Construction for their commitment to safety. They made sure every aspect of the
          project adhered to the highest safety standards.</p>
        <p class="client-name">Michael R</p>
      </div>
    </div>
  </div>
</div>

<?php include 'include/footer.php'; ?>